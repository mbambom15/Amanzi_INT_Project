/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.bl;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import za.ac.tut.entities.CustomerProfile;
import za.ac.tut.entities.Order;
import za.ac.tut.entities.Product;

/**
 *
 * @author nhlak
 */
@Stateless
public class OrderFacade extends AbstractFacade<Order> implements OrderFacadeLocal {

    @PersistenceContext(unitName = "AmanziEJBPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public OrderFacade() {
        super(Order.class);
    }

    @Override
    public List<CustomerProfile> getCustomersWithMoreThanOneOrder() {
        Query query = em.createQuery("SELECT o.customer FROM Order o GROUP BY o.customer HAVING COUNT(o) > 1");
        return query.getResultList();
    }

    @Override
    public List<Product> getOutOfStockProducts() {
        Query query = em.createQuery(
                "SELECT p FROM Product p WHERE p.stockQuantity <= 0"
        );
        return query.getResultList();

    }

    @Override
    public List<Order> findOrdersByCustomer(CustomerProfile customer) {
        Query query = em.createQuery("SELECT o FROM Order o WHERE o.customer = :cust");
        query.setParameter("cust", customer);
        return query.getResultList();
    }
}
