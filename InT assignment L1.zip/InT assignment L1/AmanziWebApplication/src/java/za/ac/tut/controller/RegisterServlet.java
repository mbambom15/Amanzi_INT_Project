/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.bl.CustomerProfileFacadeLocal;
import za.ac.tut.bl.UserFacadeLocal;
import za.ac.tut.entities.CustomerProfile;
import za.ac.tut.entities.User;

/**
 *
 * @author Gift Mashiya
 */
public class RegisterServlet extends HttpServlet {

    @EJB CustomerProfileFacadeLocal cpfl;
    private UserFacadeLocal ufl ;
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String name = request.getParameter("name");
        String username = request.getParameter("username");
        String password = request.getParameter("password") ;
        String number = request.getParameter("number");
        String address =  request.getParameter("address");
        
        CustomerProfile  custProfile = new CustomerProfile();
        User user = new User();
        
        user.setUsername(username);
        user.setPassword(password);
        
        custProfile.setName(name);
        custProfile.setAddress(address);
        custProfile.setContactNumber(number);
        custProfile.setUser(user);
        
        request.getRequestDispatcher("login.jsp").forward(request, response);
        
    
        
        
    }

}
