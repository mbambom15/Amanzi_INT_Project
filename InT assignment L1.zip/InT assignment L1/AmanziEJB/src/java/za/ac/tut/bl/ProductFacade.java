/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.bl;

import java.util.List;
import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import za.ac.tut.entities.Product;

/**
 *
 * @author nhlak
 */
@Stateless
public class ProductFacade extends AbstractFacade<Product> implements ProductFacadeLocal {

    @PersistenceContext(unitName = "AmanziEJBPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ProductFacade() {
        super(Product.class);
    }
    
    @RolesAllowed("manager")
    @Override
    public void createProduct(Product product ){
        create(product);
    }
    @RolesAllowed("manager")
    @Override
    
    public void editProduct(Product product ){
        edit(product);
    }
     
    @RolesAllowed("manager")
    @Override
     public void removeProduct(Product product ){
        remove(product);
    }
    @RolesAllowed("manager")
    @Override
     public Product findProduct(Object id ){
        Product targetProduct = find(id);
        return targetProduct;
    }
     
    
    @Override
    public List<Product>findAllProducts() {
        List<Product>list = findAll();
        return list;
    }
     
    
    
    
}
