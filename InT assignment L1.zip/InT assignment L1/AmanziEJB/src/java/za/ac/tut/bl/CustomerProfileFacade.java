/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.bl;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import za.ac.tut.entities.CustomerProfile;

/**
 *
 * @author nhlak
 */
@Stateless
public class CustomerProfileFacade extends AbstractFacade<CustomerProfile> implements CustomerProfileFacadeLocal {

    @PersistenceContext(unitName = "AmanziEJBPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public CustomerProfileFacade() {
        super(CustomerProfile.class);
    }
    
}
