/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.bl;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import za.ac.tut.entities.OrderItem;

/**
 *
 * @author khuts
 */
@Stateless
public class OrderItemFacade extends AbstractFacade<OrderItem> implements OrderItemFacadeLocal {

    @PersistenceContext(unitName = "AmanziEJBModulePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public OrderItemFacade() {
        super(OrderItem.class);
    }

    @Override
    public List<OrderItem> stockAvailable() {
        Query query = em.createQuery("SELECT o FROM OrderItem o WHERE o.quantity > 0");
        return query.getResultList();
    }
    
}
