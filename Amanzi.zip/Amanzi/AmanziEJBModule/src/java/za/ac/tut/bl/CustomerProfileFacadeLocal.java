/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.bl;

import java.util.List;
import javax.ejb.Local;
import za.ac.tut.entities.CustomerProfile;

/**
 *
 * @author khuts
 */
@Local
public interface CustomerProfileFacadeLocal {

    void create(CustomerProfile customerProfile);

    void edit(CustomerProfile customerProfile);

    void remove(CustomerProfile customerProfile);

    CustomerProfile find(Object id);

    List<CustomerProfile> findAll();

    List<CustomerProfile> findRange(int[] range);

    int count();
    
}
