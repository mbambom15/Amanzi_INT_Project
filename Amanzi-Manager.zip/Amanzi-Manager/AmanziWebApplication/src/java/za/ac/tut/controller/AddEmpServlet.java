/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.bl.EmployeeFacadeLocal;
import za.ac.tut.entities.Employee;
import za.ac.tut.entities.User;

/**
 *
 * @author nhlak
 */
public class AddEmpServlet extends HttpServlet {
    @EJB EmployeeFacadeLocal efl;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Long id = Long.parseLong(request.getParameter("id"));
        String name = request.getParameter("name");
        String username = request.getParameter("username");
        String password = request.getParameter("pswd");
        String role = request.getParameter("role");
        //add user
        User user = new User(username, password, role);
        //add emp
        Employee employee = new Employee(id, name, user);
        //
        efl.create(employee);
        //
        request.setAttribute("employee", employee);
        
        RequestDispatcher disp = request.getRequestDispatcher("add_emp_outcome.jsp");
        disp.forward(request, response);

    }

}
