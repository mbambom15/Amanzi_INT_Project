/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import za.ac.tut.bl.ManagerFacadeLocal;
import za.ac.tut.entities.Manager;
import za.ac.tut.entities.User;

/**
 *
 * @author nhlak
 */
public class SignUpServlet extends HttpServlet {
@EJB ManagerFacadeLocal mfl;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Long id = Long.parseLong(request.getParameter("id"));
        String name = request.getParameter("name");
        String username = request.getParameter("username");
        String password = request.getParameter("pswd");
        String role = request.getParameter("role");
        //create a user profile
        User user = new User(username, password, role);
        //create a manager
        Manager manager = new Manager(id, name, user);
        //
        mfl.create(manager);
        //
        response.sendRedirect("loginMgr.jsp");
    }

}
